# Jawa Timur AC - Android WebView

WebView Android untuk membuka website Google Apps Script Jawa Timur AC.

## Membuat APK melalui GitHub Actions
1. Unggah seluruh isi folder proyek ini ke repository GitHub baru (termasuk folder `.github`).
2. Buka tab **Actions** dan aktifkan workflow bila diminta.
3. Jalankan workflow **Build Jawa Timur AC APK** atau lakukan push ke branch `main`.
4. Buka hasil run yang hijau, bagian **Artifacts**, lalu unduh `jawa-timur-ac-apk`.
5. Ekstrak ZIP artifact untuk mendapatkan `app-debug.apk`, lalu instal di Android.

## Catatan kamera
Aplikasi meminta izin kamera/mikrofon Android saat halaman web meminta akses. Website juga harus meminta izin kamera melalui JavaScript browser (getUserMedia) dan berjalan di HTTPS. Izin Android saja tidak dapat memperbaiki batasan iframe atau kebijakan kamera dari Google Apps Script.
